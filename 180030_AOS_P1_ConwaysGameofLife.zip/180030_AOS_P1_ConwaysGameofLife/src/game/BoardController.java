package game;

/*
Name : Conway Game of Life using Multithreading
Author : Md Abdul Kader
Date : 25-04-2022
*/

public interface BoardController {
	
	public void updated(BoardModel m);
	
}
