package game;

/*
Name : Conway Game of Life using Multithreading
Author : Mohan Akshay Bhogadi
Date : 15/04/2021
*/

public interface BoardController {
	
	public void updated(BoardModel m);
	
}
